const express= require("express");
const index= express();
const port= 6000;

index.get('/', (req,res) => {
    res.send("Hello world")
});

index.listen(port, () => {
    console.log(`aplikasi ini berjalan di port:${port}`)
});